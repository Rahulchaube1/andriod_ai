package com.example.android_chatbot;

public interface UnsplashApiResponse {
}
